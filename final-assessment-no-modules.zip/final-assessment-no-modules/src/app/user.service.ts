import { Injectable, Output , EventEmitter } from '@angular/core';
import { Http, Response } from '@angular/http';

// import 'rxjs/Rx';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  @Output() startForm = new EventEmitter<boolean>();
 

  users=[];
  edit_values=[];
  active_id : number;
 
  url = 'https://jsonplaceholder.typicode.com/users'

   constructor(private http: Http) { }


  //ADD SECTION
  saveData(f){
    // if(this.users === null || this.users.length === 0){
    //   const users=[];
    //   users.push(f);
    // }
    // else{}
    
    //}
    console.log(this.users);
    this.users.push(f);
  }

  setData() {    
   return this.http.get(this.url)
    .pipe(map(
      (response : Response) => { 
        this.users = response.json();      
        return this.users;
      }
    ));

  }

  // setToGetData(users){
  //   this.users= users
  // }
  

  // getData(){
  //   return this.users;
    
  // }

  //EDIT SECTION
  saveEdit(f){
    this.users[this.active_id] = f;
  }

  setEdit(id :number){
   this.active_id= id;
   
  }

  getEdit(){
    return this.edit_values = this.users[this.active_id];   
  }

  //REMOVE SECTION
  setRemove(id: number){
    this.users.splice(id, 1); 
  }

  countUsers () {
    return this.users[this.users.length-1]['id']
  }

  //SHOW DETAILS SECTION

  getUserInfo(id){
    return this.users[id];
  }
}
