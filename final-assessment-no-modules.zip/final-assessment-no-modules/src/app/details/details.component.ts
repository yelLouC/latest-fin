import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  users=[]
  userInfo = [];

  id        = '';
  name      = '';
  username  = '';
  email     = '';
  street    = '';
  suite     = '';
  city      = '';
  zipcode   = '';
  lat       = '';
  lng       = '';
  phone     = '';
  website   = '';
  company_name  = '';
  catchPhrase   = '';
  bs            = '';


  constructor(private activeRoute : ActivatedRoute,
              private userService : UserService) { }

  ngOnInit() {

    this.userService.setData().subscribe(
      (user) => {
      this.users   = user;
    
      const id = this.activeRoute.snapshot.params.id;
      // this.userInfo = this.userService.getUserInfo(id-1);

      this.userInfo = this.users[id-1];

      const address = this.userInfo['address'];
      const geo     = address['geo'];
      const company     = this.userInfo['company'];


      this.id        = this.userInfo['id'];
      this.name      = this.userInfo['name'];
      this.username  = this.userInfo['username'];
      this.email     = this.userInfo['email'];
      this.street    = address['street'];
      this.suite     = address['suite'];
      this.city      = address['city'];
      this.zipcode   = address['zipcode'];
      this.lat       = geo['lat'];
      this.lng       = geo['lng'];
      this.phone     = this.userInfo['phone'];
      this.website   = this.userInfo['website'];
      this.company_name  = company['name'];
      this.catchPhrase   = company['catchPhrase'];
      this.bs            = company['bs'];
      
    });  
    
    
  }

}
