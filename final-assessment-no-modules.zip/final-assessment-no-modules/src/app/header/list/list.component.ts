import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  @Output ('pass_values') edit_values = new EventEmitter <{}>();
  @Input  ('re_emit') nothing; 

  users= [];
  
  constructor(private userService : UserService,
              private toastr: ToastrService) {}

 

  ngOnInit() {
    this.userService.setData().subscribe(
      (user) => {
        this.users   = user;
        var objDiv = document.getElementById("table_");
        objDiv.scrollTop = objDiv.scrollHeight;
      });  
    

  }

  ngOnChanges() {
      this.onReEmit(this.nothing);   
  }

  onRemove(id){  
    if(confirm('Are you sure you want to proceed?')){
      this.userService.setRemove(id);
      this.toastr.warning("User Removed Succesfully!")
    }

  }

  onEdit(id){
    this.edit_values.emit({
      id
    }); 
  }

  onReEmit(nothing){
    this.edit_values.emit({
      nothing
    }); 
  }

}
