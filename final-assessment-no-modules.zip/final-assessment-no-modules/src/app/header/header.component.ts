import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  users_id: number;
  last_id : number;
  
  isEdit : boolean =false;
  isShow : boolean =false;

  nothing;
  
  onPass(users){
    this.users_id = users.id; 
    this.isEdit = true;
  }


  onPassLastId(id){
    this.last_id = id.last_id;
  }

  reEmit(nothing){
    this.nothing = nothing;
  }

}
