import { Component, OnInit, ViewChild, Input, EventEmitter , Output, OnChanges } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  @Input('values') user_id; 
  @Input('') editMode   : boolean = false;
  @Output ('re_emit') re_emit = new EventEmitter <{}>();

  @ViewChild ('f') myform;

  edit_values=[];
  
  container ={};

  edit_mode= false;
  last_id: number;

  constructor( private userService : UserService,
               private toastr : ToastrService
             ) { }

  ngOnInit() {
  }

  ngOnChanges() {
    console.log(this.user_id);
    if(this.user_id||this.user_id==0){
      if (this.editMode) { 
        this.onEdit(this.user_id);  
        this.edit_mode = this.editMode
      }   
    }
    
    // this.myform.form.setValue({
    //   id                  :'',
    //   name                :'',
    //   username            :'',
    //   email               :'',
     
    //   street              :'',
    //   suite               :'',
    //   city                :'',
    //   zipcode             :'',
            
    //   lat                 :'',
    //   lng                 :'',

     
    //   phone               :'',
    //   website             :'',
 
    //   cname               :'',
    //   catchPhrase         :'',
    //   bs                  :'',

    // });
    
  }


  // FOR ADD
  onSubmit(){

    this.last_id = this.userService.countUsers();
    

    this.container={
      id        :this.last_id + 1,
      name      :this.myform.value.name,
      username  :this.myform.value.username,
      email     :this.myform.value.email,
      address:{
              street  :this.myform.value.street,
              suite   :this.myform.value.suite,
              city    :this.myform.value.city,
              zipcode :this.myform.value.zipcode,
              geo:{
                  lat:this.myform.value.lat,
                  lng:this.myform.value.lng,
              }
      },
      phone  :this.myform.value.phone,
      website:this.myform.value.website,
      company:{
              name       :this.myform.value.cname,
              catchPhrase:this.myform.value.catchPhrase,
              bs         :this.myform.value.bs
      }    
    };

    this.userService.saveData(this.container);
    this.toastr.success("New User Inserted Successfully!");
     this.myform.reset();

     var objDiv = document.getElementById("table_");
     objDiv.scrollTop = objDiv.scrollHeight;
  }


  // FOR EDIT
  onEdit(id){
    
    this.userService.setEdit(id);
    this.edit_values = this.userService.getEdit();

    const address    = this.edit_values['address']
    const geo        = address['geo']
    const company    = this.edit_values['company']
    
    
    this.myform.form.patchValue({
      id                  :this.edit_values['id'],
      name                :this.edit_values['name'],
      username            :this.edit_values['username'],
      email               :this.edit_values['email'],
     
      street              :address['street'],
      suite               :address['suite'],
      city                :address['city'],
      zipcode             :address['zipcode'],
            
      lat                 :geo['lat'],
      lng                 :geo['lng'],

     
      phone               :this.edit_values['phone'],
      website             :this.edit_values['website'],
 
      cname               :company['name'],
      catchPhrase         :company['catchPhrase'],
      bs                  :company['bs']

    });

    
  }

  onUpdate(){
    this.re_emit.emit({
      nothing: 0
     });  

     
    this.edit_mode = false;
    this.container={
      id          :this.edit_values['id'],
      name        :this.myform.value.name,
      username    :this.myform.value.username,
      email       :this.myform.value.email,
      address:{
              street    :this.myform.value.street,
              suite     :this.myform.value.suite,
              city      :this.myform.value.city,
              zipcode   :this.myform.value.zipcode,
              geo:{
                  lat   :this.myform.value.lat,
                  lng   :this.myform.value.lng,
              }
      },
      phone      :this.myform.value.phone,
      website     :this.myform.value.website,
      company:{
              name            :this.myform.value.cname,
              catchPhrase     :this.myform.value.catchPhrase,
              bs              :this.myform.value.bs
      }
      
    };
    this.userService.saveEdit(this.container);
    this.toastr.info("User Updated Succesfully!")
    this.myform.reset();
    
  }

  

  onClear(){
      this.myform.reset();  
  }

  onCancel(){
    
    this.re_emit.emit({
     nothing: 0
    });  

    this.myform.reset();
    this.edit_mode = false;
  }

}
